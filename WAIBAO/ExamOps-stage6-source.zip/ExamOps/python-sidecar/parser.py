"""Structured text extraction. OCR models are local and loaded only when needed.

`parse_structured()` returns units (pages / slides / paragraphs / line blocks)
with heading marks, extracted figures and a plain-text rendition; see
structure.py and docs/API.md (sidecar protocol) for the format.
"""
from contextlib import closing
from io import BytesIO
from pathlib import Path
import json
import re
import sys

import chapters
from figures import Figures
from structure import Block, Unit


class DocumentError(ValueError):
    """A problem with the user's file that should be shown as-is."""


class Ocr:
    def __init__(self):
        self.engine = None

    def lines(self, image):
        if self.engine is None:
            import rapidocr
            from rapidocr import RapidOCR

            models = Path(rapidocr.__file__).parent / "models"
            self.engine = RapidOCR(params={
                "Global.log_level": "error",
                "Det.model_path": str(models / "PP-OCRv6_det_small.onnx"),
                "Cls.model_path": str(models / "ch_ppocr_mobile_v2.0_cls_mobile.onnx"),
                "Rec.model_path": str(models / "PP-OCRv6_rec_small.onnx"),
                "EngineConfig.onnxruntime.intra_op_num_threads": 2,
                "EngineConfig.onnxruntime.inter_op_num_threads": 1,
            })
        result = self.engine(image)
        if result.txts is None:
            return []
        return list(zip(result.boxes, result.txts))

    def image_text(self, blob):
        from PIL import Image
        with Image.open(BytesIO(blob)) as image:
            return "\n".join(text for _, text in self.lines(image.convert("RGB")))


class Progress:
    """Reports `{"progress": {...}}` JSON lines on stderr when enabled."""

    def __init__(self, enabled=False):
        self.enabled = enabled

    def __call__(self, current, total, stage="page"):
        if self.enabled:
            print(json.dumps({"progress": {"stage": stage, "current": current, "total": total}}),
                  file=sys.stderr, flush=True)


def normalized(text):
    return re.sub(r"\W+", "", text, flags=re.UNICODE).casefold()


# --------------------------------------------------------------------------- PDF

def _line_sizes(textpage):
    """Maps normalized line text to its font size, sampled at the start of each text rect."""
    import pypdfium2.raw as raw

    sizes = {}
    try:
        for index in range(textpage.count_rects()):
            left, bottom, right, top = textpage.get_rect(index)
            text = textpage.get_text_bounded(left, bottom, right, top).strip()
            key = normalized(text)
            if not key:
                continue
            char = textpage.get_index(left + 1, (bottom + top) / 2, 3, 3)
            size = raw.FPDFText_GetFontSize(textpage, char) if char is not None and char >= 0 else 0
            sizes[key] = max(sizes.get(key, 0.0), size or (top - bottom))
    except Exception:
        return {}
    return sizes


def _read_toc(pdf):
    toc = []
    try:
        for bookmark in pdf.get_toc(max_depth=4):
            dest = bookmark.get_dest()
            toc.append((bookmark.level, bookmark.get_title(), dest.get_index() if dest else None))
    except Exception:
        return []
    return toc


def parse_pdf(path, ocr, figures, progress):
    import pypdfium2 as pdfium
    import pypdfium2.raw as raw

    units = []
    try:
        pdf = pdfium.PdfDocument(path)
    except pdfium.PdfiumError as error:
        if "password" in str(error).lower():
            raise DocumentError("PDF 已加密，请先在其他软件中解除密码保护后再导入") from error
        raise DocumentError(f"无法打开 PDF（文件可能已损坏）：{error}") from error
    with pdf:
        total = len(pdf)
        toc = _read_toc(pdf)
        for number in range(total):
            progress(number + 1, total)
            with closing(pdf[number]) as page, closing(page.get_textpage()) as textpage:
                native = textpage.get_text_bounded().strip()
                sizes = _line_sizes(textpage) if native else {}
                blocks = [Block(line.strip(), size=sizes.get(normalized(line)))
                          for line in native.splitlines() if line.strip()]
                extra = []
                has_images = any(page.get_objects(filter=[raw.FPDF_PAGEOBJ_IMAGE]))
                if has_images or not native:
                    # Render one page at a time; coordinates account for rotation/crop boxes.
                    scale = min(2.5, 3000 / max(page.get_size()))
                    with closing(page.render(scale=scale)) as bitmap:
                        conversion = bitmap.get_posconv(page)
                        image = bitmap.to_pil()
                        try:
                            for box, text in ocr.lines(image):
                                points = [conversion.to_page(round(x), round(y)) for x, y in box]
                                xs, ys = zip(*points)
                                covered = textpage.get_text_bounded(
                                    min(xs) - 2, min(ys) - 2, max(xs) + 2, max(ys) + 2
                                )
                                # Only deduplicate text from the SAME location, not equal
                                # phrases elsewhere in the page or on another page.
                                recognized, existing = normalized(text), normalized(covered)
                                if existing and recognized and (recognized in existing or
                                        (existing in recognized and len(existing) / len(recognized) > 0.9)):
                                    continue
                                extra.append(text)
                        finally:
                            image.close()
                if has_images:
                    figures.extract_pdf_page(page, number + 1)
                blocks.extend(Block(text, kind="ocr") for text in extra if text.strip())
                width, height = page.get_size()
                units.append(Unit(number + 1, f"第 {number + 1} 页", blocks, round(width, 1),
                                  round(height, 1), ocr=bool(extra)))
    source = chapters.detect(units, "pdf", toc)
    for unit in units:
        merge_lines(unit)
    return units, source, "page"


TERMINAL = tuple("。！？；：.!?;:」』”）)")


def _is_cjk(char):
    return "\u3040" <= char <= "\u30ff" or "\u3400" <= char <= "\u9fff" or "\uf900" <= char <= "\ufaff"


def merge_lines(unit):
    """Joins PDF lines that were wrapped by the page layout back into paragraphs."""
    lengths = sorted(len(b.text) for b in unit.blocks if b.kind == "text" and not b.heading and len(b.text) >= 10)
    typical = lengths[len(lengths) * 3 // 4] if lengths else 0
    merged = []
    for block in unit.blocks:
        previous = merged[-1] if merged else None
        joinable = (
            previous is not None and typical
            and previous.kind == "text" and block.kind == "text"
            and previous.heading is None and block.heading is None
            and not previous.text.endswith(TERMINAL)
            and not chapters.TOC_LINE.search(previous.text) and not chapters.TOC_LINE.search(block.text)
            and len(previous.text.splitlines()[-1]) >= typical * 0.8
            and not (previous.size and block.size and abs(previous.size - block.size) > 1.5)
        )
        if joinable:
            tail, head = previous.text[-1], block.text[0]
            if tail == "-" and head.islower():
                previous.text = previous.text[:-1] + block.text
            elif _is_cjk(tail) or _is_cjk(head):
                previous.text += block.text
            else:
                previous.text += " " + block.text
        else:
            merged.append(Block(block.text, block.heading, block.kind, block.size, block.source))
    unit.blocks = merged


# --------------------------------------------------------------------------- Word

def _docx_heading_level(paragraph, qn, style_names):
    properties = paragraph.find(qn("w:pPr"))
    if properties is None:
        return None
    outline = properties.find(qn("w:outlineLvl"))
    if outline is not None:
        try:
            level = int(outline.get(qn("w:val")))
            if 0 <= level <= 5:
                return level + 1
        except (TypeError, ValueError):
            pass
    style = properties.find(qn("w:pStyle"))
    if style is None:
        return None
    name = style_names.get(style.get(qn("w:val")), "").strip().lower()
    match = re.match(r"^(?:heading|标题)\s*(\d)$", name)
    return int(match.group(1)) if match else None


def parse_docx(path, ocr, figures, progress):
    from docx import Document
    from docx.oxml.ns import qn

    try:
        document = Document(path)
    except Exception as error:
        raise DocumentError(f"无法读取 Word 文件（可能已损坏，或是旧版 .doc 格式，请另存为 .docx）：{error}") from error
    style_names = {style.style_id: style.name or "" for style in document.styles}
    paragraphs = list(document.element.body.iter(qn("w:p")))
    units = []
    for position, paragraph in enumerate(paragraphs):
        if position % 50 == 0:
            progress(position + 1, len(paragraphs), "paragraph")
        number = len(units) + 1
        line, images = [], []
        # Walk body XML so text, tables and inline/floating images stay in document order.
        for node in paragraph.iter():
            if node.tag == qn("w:t") and node.text:
                line.append(node.text)
            elif node.tag in (qn("w:tab"), qn("w:br")):
                line.append("\t" if node.tag == qn("w:tab") else "\n")
            elif node.tag == qn("a:blip"):
                rel_id = node.get(qn("r:embed"))
                part = document.part.related_parts.get(rel_id) if rel_id else None
                if part is not None:
                    text = ocr.image_text(part.blob)
                    images.append((part.blob, text))
                    line.append("\n" + text + "\n")
        text = "".join(line).strip()
        if not text and not images:
            continue
        for blob, ocr_text in images:
            figures.save_blob(blob, number, ocr_text)
        level = _docx_heading_level(paragraph, qn, style_names) if text and "\n" not in text else None
        units.append(Unit(number, f"第 {number} 段", [Block(text or "（图片）", heading=level,
                                                            source="styles" if level else None)]))
    source = chapters.detect(units, "docx")
    return units, source, "paragraph"


# --------------------------------------------------------------------------- PowerPoint

def _pptx_sections(presentation):
    """Returns {slide_number: section_name} from the PowerPoint 2010 section list."""
    try:
        root = presentation.part._element
        ids = [int(s.get("id")) for s in presentation.slides._sldIdLst]
        sections = {}
        for section in root.iter("{http://schemas.microsoft.com/office/powerpoint/2010/main}section"):
            name = (section.get("name") or "").strip()
            members = [int(s.get("id")) for s in section.iter(
                "{http://schemas.microsoft.com/office/powerpoint/2010/main}sldId")]
            if name and members and members[0] in ids:
                sections[ids.index(members[0]) + 1] = name
        # PowerPoint adds a "Default Section"/"默认节" when sections are unused.
        if len(sections) == 1 and list(sections.values())[0].lower() in ("default section", "默认节"):
            return {}
        return sections
    except Exception:
        return {}


def parse_pptx(path, ocr, figures, progress):
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    try:
        presentation = Presentation(path)
    except Exception as error:
        raise DocumentError(f"无法读取 PPT 文件（可能已损坏，或是旧版 .ppt 格式，请另存为 .pptx）：{error}") from error
    sections = _pptx_sections(presentation)

    def shape_blocks(shapes, number, skip_id):
        blocks = []
        for shape in shapes:
            if shape.shape_id == skip_id:
                continue
            if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                blocks.extend(shape_blocks(shape.shapes, number, skip_id))
            elif shape.shape_type == MSO_SHAPE_TYPE.PICTURE or (
                    shape.is_placeholder and hasattr(shape, "image")):
                try:
                    blob = shape.image.blob
                except Exception:
                    continue
                text = ocr.image_text(blob)
                figures.save_blob(blob, number, text)
                if text.strip():
                    blocks.append(Block(text, kind="ocr"))
            elif shape.has_table:
                rows = ["\t".join(cell.text for cell in row.cells if not cell.is_spanned)
                        for row in shape.table.rows]
                blocks.append(Block("\n".join(rows), kind="table"))
            elif shape.has_text_frame and shape.text.strip():
                blocks.append(Block(shape.text.strip()))
        return blocks

    units = []
    slides = list(presentation.slides)
    for number, slide in enumerate(slides, 1):
        progress(number, len(slides), "slide")
        blocks = []
        if number in sections:
            blocks.append(Block(sections[number], heading=1, kind="section", source="slides"))
        title_shape = slide.shapes.title
        title = title_shape.text.strip() if title_shape is not None and title_shape.has_text_frame else ""
        if title:
            blocks.append(Block(title, kind="title"))
        body = shape_blocks(slide.shapes, number, title_shape.shape_id if title_shape is not None else None)
        if not title and body and body[0].kind == "text" and len(body[0].text.splitlines()[0]) <= 40:
            # No title placeholder: the first short text line usually acts as the title.
            first = body[0].text.splitlines()
            blocks.append(Block(first[0], kind="title"))
            body[0] = Block("\n".join(first[1:]))
        blocks.extend(b for b in body if b.text.strip())
        units.append(Unit(number, f"第 {number} 张幻灯片", blocks,
                          meta={"layout": slide.slide_layout.name or ""}))
    source = chapters.detect(units, "pptx")
    return units, source, "slide"


# --------------------------------------------------------------------------- Text / Markdown

def decode_text(data):
    """UTF-8 first; otherwise detect the encoding (GBK/GB18030 and Big5 are common
    for Chinese course notes). charset-normalizer is MIT-licensed."""
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        pass
    from charset_normalizer import from_bytes
    best = from_bytes(data).best()
    if best is not None and best.encoding:
        return str(best)
    for encoding in ("gb18030", "big5"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise DocumentError("无法识别文本编码，请另存为 UTF-8 后导入")


MD_HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$")
FENCE = re.compile(r"^\s{0,3}(```|~~~)")


def parse_text(path, markdown, progress, max_lines=40):
    lines = decode_text(Path(path).read_bytes()).splitlines()
    units = []
    current, start = [], 0

    def flush(end):
        nonlocal current
        if current and any(l.strip() for l, _ in current):
            heading = current[0][1] if len(current) == 1 else None
            text = "\n".join(l for l, _ in current).strip("\n")
            number = len(units) + 1
            first, last = start + 1, end
            label = f"第 {first} 行" if first == last else f"第 {first}–{last} 行"
            units.append(Unit(number, label, [Block(text, heading=heading,
                                                    source="markdown" if heading else None)],
                              loc_start=first, loc_end=last))
        current = []

    in_fence = False
    for index, raw_line in enumerate(lines):
        line = raw_line.rstrip()
        if markdown and FENCE.match(line):
            in_fence = not in_fence
        heading = None
        if markdown and not in_fence:
            match = MD_HEADING.match(line)
            if match:
                heading = len(match.group(1))
                # Chapter titles and the reader show the heading without its "#" marks.
                line = match.group(2).strip()
            elif (re.fullmatch(r"\s{0,3}(=+|-+)\s*", line) and current and len(current) == 1
                  and current[0][0].strip() and index > 0):
                # Setext heading: previous single line underlined with === or ---.
                current[0] = (current[0][0], 1 if line.strip()[0] == "=" else 2)
                flush(index + 1)
                start = index + 1
                continue
        if heading or (not in_fence and chapters.looks_like_heading(line)):
            # Headings become their own unit so chapters start exactly at that line.
            flush(index)
            start = index
            current = [(line, heading)]
            flush(index + 1)
            start = index + 1
            continue
        if not line.strip() and not in_fence:
            flush(index)
            start = index + 1
            continue
        if not current:
            start = index
        current.append((line, None))
        if len(current) >= max_lines and not in_fence:
            flush(index + 1)
            start = index + 1
    flush(len(lines))
    progress(1, 1, "text")
    source = chapters.detect(units, "md" if markdown else "txt")
    return units, source, "line"


# --------------------------------------------------------------------------- entry points

def plain_text(units, loc_kind):
    sections = []
    for unit in units:
        body = unit.text.strip()
        if not body:
            continue
        sections.append(f"[{unit.label}]\n{body}" if loc_kind in ("page", "slide") else body)
    return ("\n\n" if loc_kind in ("page", "slide", "line") else "\n").join(sections)


def parse_structured(path, figures_dir=None, progress=None):
    path = Path(path)
    ocr = Ocr()
    figures = Figures(figures_dir)
    progress = progress or Progress(False)
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        units, source, loc_kind = parse_pdf(path, ocr, figures, progress)
    elif suffix == ".docx":
        units, source, loc_kind = parse_docx(path, ocr, figures, progress)
    elif suffix == ".pptx":
        units, source, loc_kind = parse_pptx(path, ocr, figures, progress)
    elif suffix in (".txt", ".md", ".markdown"):
        units, source, loc_kind = parse_text(path, suffix != ".txt", progress)
    else:
        raise DocumentError("不支持的文件格式")
    content = plain_text(units, loc_kind).strip()
    if not content:
        raise DocumentError("未提取到正文（已对图片尝试 OCR），请检查资料内容或扫描清晰度")
    warnings = []
    if figures.skipped:
        warnings.append(f"{figures.skipped} 张图片因格式不支持或数量过多未保存")
    if loc_kind == "page" and units and sum(u.ocr for u in units) == len(units):
        warnings.append("全部页面为扫描件，正文来自 OCR，可能存在识别错误")
    return {
        "content": content,
        "loc_kind": loc_kind,
        "structure_source": source,
        "pages": [unit.to_json() for unit in units],
        "images": figures.items,
        "warnings": warnings,
    }


def parse_document(path):
    """Plain text only (phase-one interface)."""
    return parse_structured(path)["content"]
